from tkinter import *
import socket
import errno
from datetime import datetime
import sys
import subprocess
import os
import time
from bin import testerd

def Enlace():
    def Chat():
        ventana = Tk()
        ventana.title("Registro ...")
        ventana.geometry("690x150+400+400")
        colorFondo = '#000'
        ventana.resizable(width=FALSE, height=FALSE)
        ventana.config(bg=colorFondo)
        ventana.iconbitmap('bin.ico')

        NombredeUsuario = StringVar()

        Etiqueta_USERNAME = Label(ventana, text="Nombre de Usuario: ", fg='#01F436', bg=colorFondo,
                                  font=("VERDANA", 18)).place(x=10, y=55)
        Entrada_USERNAME = Entry(ventana, textvariable=NombredeUsuario, fg='#000', bg='#02AAF1',
                                 font=("VERDANA", 18)).place(x=260, y=55)

        def TransmitirValor():

            HEADER_LENGTH = 10

            IP = "192.168.1.34"
            PORT = 2356

            my_username = NombredeUsuario.get()
            ventana.destroy()

            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                client_socket.connect((IP, PORT))
            except ConnectionRefusedError:
                print("Lo siento el servidor esta apagado intentalo de nuevo mas tarde.")
            client_socket.setblocking(False)

            username = my_username.encode("utf-8")
            username_header = f"{len(username):<{HEADER_LENGTH}}".encode("utf-8")
            client_socket.send(username_header + username)
            clear = lambda: os.system('cls')

            clear()

            while True:
                print('--------------------UNDERBLOCK--------------------')
                message = input(f"[{my_username}]>> ")

                if message:
                    message = message.encode("utf-8")
                    message_header = f"{len(message):<{HEADER_LENGTH}}".encode("utf-8")
                    client_socket.send(message_header + message)
                try:
                    while True:
                        dt = datetime.now()
                        username_header = client_socket.recv(HEADER_LENGTH)
                        if not len(username_header):
                            print("Coneccion cerrada por el servidor")
                            sys.exit()
                        username_length = int(username_header.decode("utf-8").strip())
                        username = client_socket.recv(username_length).decode("utf-8")

                        message_header = client_socket.recv(HEADER_LENGTH)
                        message_length = int(message_header.decode("utf-8").strip())
                        message = client_socket.recv(message_length).decode('utf-8')

                        print(f"[{dt.day}][{dt.hour}:{dt.minute}:{dt.second}][{username}]>> {message}")
                except IOError as e:
                    if e.errno != errno.EAGAIN and e.errno != errno.EWOULDBLOCK:
                        print('Error Fatal', str(e))
                        sys.exit()
                    continue

                except Exception as e:
                    print(f"Error General", str(e))
                    sys.exit()

        Boton_USERNAME = Button(ventana, text='OK!', font=("VERDANA", 18), fg='#EDFF0C', bd=5, bg=colorFondo, width=3,
                                height=1, command=TransmitirValor).place(x=580, y=50)

        ventana.mainloop()

testerd.muidf()



